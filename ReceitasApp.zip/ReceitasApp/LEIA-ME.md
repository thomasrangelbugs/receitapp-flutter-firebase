# ReceitApp — Guia de Agentes de Desenvolvimento

> Divisão de tarefas para construção do app de receitas em Flutter + Firebase usando agentes de IA especializados.

---

## Visão geral

O projeto é dividido em **7 agentes especializados**, cada um responsável por uma camada ou funcionalidade. Eles devem ser executados **em ordem**, pois cada agente depende do trabalho do anterior.

```
Agente 01 → Agente 02 → Agente 03 → Agente 04 → Agente 05 → Agente 06 → Agente 07
Arquiteto    Auth        Receitas     Listas       Navegação    Timer        Polimento
```

---

## Mapa de agentes

| # | Arquivo | Responsabilidade | Depende de |
|---|---------|-----------------|------------|
| 01 | `agente-01-arquiteto.md` | Estrutura, modelos, Firebase, tema | — |
| 02 | `agente-02-autenticacao.md` | Login, cadastro, logout, guard de rotas | 01 |
| 03 | `agente-03-crud-receitas.md` | CRUD completo de receitas + detalhes | 01, 02 |
| 04 | `agente-04-crud-listas.md` | CRUD completo de listas + integração | 01, 02, 03 |
| 05 | `agente-05-navegacao-home.md` | BottomNav, Home, AppBar, roteamento | 01–04 |
| 06 | `agente-06-timer.md` | Timer com alarme sonoro (recurso extra) | 01, 05 |
| 07 | `agente-07-polimento-entrega.md` | Validações, erros, docs, README | 01–06 |

---

## Como usar

### Opção A — Um agente por sessão (recomendado)
1. Abra uma nova conversa com a IA
2. Cole o conteúdo do agente correspondente como **system prompt** ou primeira mensagem
3. Diga: *"Execute suas tarefas conforme descrito. Ao finalizar, liste os entregáveis."*
4. Confirme os entregáveis antes de iniciar o próximo agente

### Opção B — Agente sequencial em uma sessão
1. Cole o agente 01 e execute
2. Confirme: *"Agente 01 concluído. Agora execute o Agente 02."*
3. Cole o próximo agente e repita

---

## Requisitos do trabalho × agentes

| Requisito | Agente responsável |
|-----------|-------------------|
| 1. Login e cadastro de usuário | Agente 02 |
| 2. UI/UX fluida e navegação | Agentes 01, 05, 07 |
| 3. Pelo menos 2 CRUDs com validação | Agentes 03, 04 |
| 4. Listagem/relatório dos dados | Agentes 03, 04, 05 |
| 5. Menu centralizado | Agente 05 |
| 6. Recurso extra (timer com alarme) | Agente 06 |

---

## Arquitetura do projeto

```
lib/
├── core/           # tema, rotas, constantes
├── models/         # ReceitaModel, ListaModel, etc.
├── services/       # AuthService, ReceitaService, ListaService
├── screens/
│   ├── auth/       # login, cadastro, splash
│   ├── home/       # home screen
│   ├── receitas/   # list, form, detail
│   ├── listas/     # list, form, detail
│   └── timer/      # timer screen + controller
└── widgets/
    └── common/     # AppBar, EmptyState, etc.
```

---

## Pontos de integração entre agentes

| Integração | Agente origem | Agente destino |
|-----------|--------------|---------------|
| `ReceitaService` na `ListaDetalheScreen` | Agente 03 | Agente 04 |
| Botão "Iniciar timer" na etapa | Agente 03 | Agente 06 |
| `removerReceitaDasListas` ao excluir receita | Agente 04 | Agente 03 |
| `AppBarPadrao` usada em todas as telas | Agente 05 | Agentes 03, 04, 06 |
| `ErrorHandler` substituindo catch genéricos | Agente 07 | Todos |

---

## Tecnologias utilizadas

- **Flutter** 3.x / **Dart** 3.x
- **Firebase Auth** — autenticação
- **Cloud Firestore** — banco de dados
- **GoRouter** — roteamento declarativo
- **Provider** — gerenciamento de estado
- **audioplayers** — alarme sonoro do timer
- **intl** — formatação de datas
- **uuid** — geração de IDs únicos
