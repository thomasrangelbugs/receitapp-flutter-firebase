import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../controllers/receitas_busca_controller.dart';
import '../../core/constants.dart';
import '../../core/error_handler.dart';
import '../../models/receita_model.dart';
import '../../services/auth_service.dart';
import '../../services/lista_service.dart';
import '../../services/receita_service.dart';
import '../../widgets/common/empty_state.dart';

class ReceitasScreen extends StatefulWidget {
  const ReceitasScreen({super.key});

  @override
  State<ReceitasScreen> createState() => _ReceitasScreenState();
}

class _ReceitasScreenState extends State<ReceitasScreen> {
  final _buscaController = TextEditingController();

  @override
  void dispose() {
    _buscaController.dispose();
    super.dispose();
  }

  Future<void> _excluirReceita(
    BuildContext context,
    ReceitaModel receita,
  ) async {
    final confirmou = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Excluir receita?'),
          content: Text('Tem certeza que deseja excluir ${receita.titulo}?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Excluir'),
            ),
          ],
        );
      },
    );

    if (confirmou != true) {
      return;
    }

    try {
      final userId = context.read<AuthService>().usuarioAtual?.uid;
      await context.read<ReceitaService>().excluir(receita.id);
      if (userId != null) {
        await context.read<ListaService>().removerReceitaDasListas(
              userId: userId,
              receitaId: receita.id,
            );
      }
      if (context.mounted) {
        ErrorHandler.mostrarSucesso(context, 'Receita excluida.');
      }
    } catch (erro) {
      if (context.mounted) {
        ErrorHandler.mostrarErro(context, 'Falha ao excluir receita.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final receitas = context.watch<List<ReceitaModel>>();
    final buscaController = context.watch<ReceitasBuscaController>();
    final receitasFiltradas = context
        .read<ReceitaService>()
        .filtrarPorTitulo(receitas, _buscaController.text);

    return RefreshIndicator(
      onRefresh: () async {
        await Future.delayed(const Duration(milliseconds: 600));
      },
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (buscaController.mostrarBusca)
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TextField(
                controller: _buscaController,
                decoration: InputDecoration(
                  hintText: 'Buscar receita...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () {
                      _buscaController.clear();
                      buscaController.ocultar();
                      setState(() {});
                    },
                  ),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
          if (receitasFiltradas.isEmpty)
            EmptyStateWidget(
              icone: Icons.receipt_long,
              titulo: buscaController.mostrarBusca
                  ? 'Nenhuma receita encontrada'
                  : 'Nenhuma receita cadastrada',
              descricao: buscaController.mostrarBusca
                  ? 'Tente buscar com outro termo.'
                  : 'Adicione sua primeira receita.',
              acao: ElevatedButton(
                onPressed: () => context.go(Rotas.caminhoReceitaNova),
                child: const Text('Nova receita'),
              ),
            )
          else
            ...receitasFiltradas.map((receita) {
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(
                    child: Icon(Icons.restaurant),
                  ),
                  title: Text(receita.titulo),
                  subtitle: Text(
                    '${receita.tempoPreparo} min • ${receita.porcoes} porcoes',
                  ),
                  onTap: () => context.go(
                    '${Rotas.caminhoReceitas}/${receita.id}',
                  ),
                  trailing: PopupMenuButton<String>(
                    onSelected: (valor) {
                      if (valor == 'editar') {
                        context.go(
                          '${Rotas.caminhoReceitas}/${receita.id}/editar',
                        );
                      } else if (valor == 'excluir') {
                        _excluirReceita(context, receita);
                      }
                    },
                    itemBuilder: (context) => const [
                      PopupMenuItem(
                        value: 'editar',
                        child: Text('Editar'),
                      ),
                      PopupMenuItem(
                        value: 'excluir',
                        child: Text('Excluir'),
                      ),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}
