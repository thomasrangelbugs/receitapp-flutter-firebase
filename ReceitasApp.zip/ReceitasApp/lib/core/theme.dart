import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static final ColorScheme _esquemaCores = ColorScheme.fromSeed(
    seedColor: const Color(0xFFB85C38),
    primary: const Color(0xFFB85C38),
    secondary: const Color(0xFF6B8E23),
    surface: const Color(0xFFFFF4E8),
  );

  static final TextTheme _textoBase = GoogleFonts.latoTextTheme().copyWith(
    headlineLarge: GoogleFonts.playfairDisplay(
      fontSize: 32,
      fontWeight: FontWeight.w700,
      color: const Color(0xFF3A2E2A),
    ),
    titleLarge: GoogleFonts.playfairDisplay(
      fontSize: 22,
      fontWeight: FontWeight.w600,
      color: const Color(0xFF3A2E2A),
    ),
    bodyLarge: GoogleFonts.lato(
      fontSize: 16,
      fontWeight: FontWeight.w400,
      color: const Color(0xFF3A2E2A),
    ),
    bodyMedium: GoogleFonts.lato(
      fontSize: 14,
      fontWeight: FontWeight.w400,
      color: const Color(0xFF3A2E2A),
    ),
  );

  static final ThemeData claro = ThemeData(
    useMaterial3: true,
    colorScheme: _esquemaCores,
    scaffoldBackgroundColor: const Color(0xFFFFF8F1),
    textTheme: _textoBase,
    appBarTheme: AppBarTheme(
      backgroundColor: _esquemaCores.primary,
      foregroundColor: _esquemaCores.onPrimary,
      centerTitle: true,
      elevation: 0,
      titleTextStyle: _textoBase.titleLarge?.copyWith(
        color: _esquemaCores.onPrimary,
      ),
    ),
    cardTheme: CardTheme(
      color: _esquemaCores.surface,
      elevation: 1,
      margin: const EdgeInsets.all(12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFFFFEFE2),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: _esquemaCores.outline),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: _esquemaCores.primary,
        foregroundColor: _esquemaCores.onPrimary,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    ),
  );
}
