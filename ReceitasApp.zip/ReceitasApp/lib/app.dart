import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import 'core/constants.dart';
import 'core/routes.dart';
import 'core/theme.dart';
import 'services/auth_service.dart';

class ReceitApp extends StatefulWidget {
  const ReceitApp({super.key});

  @override
  State<ReceitApp> createState() => _ReceitAppState();
}

class _ReceitAppState extends State<ReceitApp> {
  GoRouter? _router;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _router ??= criarRouter(context.read<AuthService>());
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: ConstantesApp.nomeApp,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.claro,
      routerConfig: _router,
    );
  }
}
