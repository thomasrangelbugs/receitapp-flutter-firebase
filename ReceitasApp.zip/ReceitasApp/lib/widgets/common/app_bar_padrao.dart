import 'package:flutter/material.dart';

import 'logout_button.dart';

/// AppBar padrao do aplicativo com acao de logout.
class AppBarPadrao extends StatelessWidget implements PreferredSizeWidget {
  final String titulo;
  final List<Widget> acoes;
  final bool mostrarVoltar;
  final bool mostrarLogout;

  const AppBarPadrao({
    super.key,
    required this.titulo,
    this.acoes = const [],
    this.mostrarVoltar = false,
    this.mostrarLogout = true,
  });

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text(titulo),
      automaticallyImplyLeading: mostrarVoltar,
      actions: [
        ...acoes,
        if (mostrarLogout) const BotaoLogout(),
      ],
    );
  }
}
