import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../controllers/receitas_busca_controller.dart';
import '../../core/constants.dart';
import '../../models/lista_model.dart';
import '../../models/receita_model.dart';
import '../../services/auth_service.dart';
import '../../services/lista_service.dart';
import '../../services/receita_service.dart';
import 'app_bar_padrao.dart';

/// Shell com navegacao inferior e AppBar dinamica.
class NavShell extends StatelessWidget {
  final StatefulNavigationShell navigationShell;

  const NavShell({super.key, required this.navigationShell});

  @override
  Widget build(BuildContext context) {
    final authService = context.watch<AuthService>();
    final receitaService = context.read<ReceitaService>();
    final listaService = context.read<ListaService>();
    final userId = authService.usuarioAtual?.uid;

    final streamReceitas = userId == null
        ? Stream<List<ReceitaModel>>.value(const [])
        : receitaService.listar(userId);
    final streamListas = userId == null
        ? Stream<List<ListaModel>>.value(const [])
        : listaService.listar(userId);

    return MultiProvider(
      providers: [
        StreamProvider<List<ReceitaModel>>.value(
          value: streamReceitas,
          initialData: const [],
        ),
        StreamProvider<List<ListaModel>>.value(
          value: streamListas,
          initialData: const [],
        ),
        ChangeNotifierProvider<ReceitasBuscaController>(
          create: (_) => ReceitasBuscaController(),
        ),
      ],
      child: Scaffold(
        appBar: AppBarPadrao(
          titulo: _tituloAtual(navigationShell.currentIndex),
          acoes: _acoesParaIndex(context, navigationShell.currentIndex),
        ),
        body: navigationShell,
        floatingActionButton:
            _fabParaIndex(context, navigationShell.currentIndex),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: navigationShell.currentIndex,
          onTap: (index) => _irParaBranch(index),
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Inicio',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.receipt_long),
              label: 'Receitas',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.list_alt),
              label: 'Listas',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.timer),
              label: 'Timer',
            ),
          ],
        ),
      ),
    );
  }

  void _irParaBranch(int index) {
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  String _tituloAtual(int index) {
    switch (index) {
      case 0:
        return 'Inicio';
      case 1:
        return 'Receitas';
      case 2:
        return 'Listas';
      case 3:
        return 'Timer';
      default:
        return 'ReceitApp';
    }
  }

  List<Widget> _acoesParaIndex(BuildContext context, int index) {
    switch (index) {
      case 1:
        return [
          IconButton(
            icon: const Icon(Icons.search),
            tooltip: 'Pesquisar',
            onPressed: () {
              context.read<ReceitasBuscaController>().alternar();
            },
          ),
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Nova receita',
            onPressed: () => context.go(Rotas.caminhoReceitaNova),
          ),
        ];
      case 2:
        return [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Nova lista',
            onPressed: () => context.go(Rotas.caminhoListaNova),
          ),
        ];
      default:
        return [];
    }
  }

  Widget? _fabParaIndex(BuildContext context, int index) {
    switch (index) {
      case 1:
        return FloatingActionButton(
          onPressed: () => context.go(Rotas.caminhoReceitaNova),
          child: const Icon(Icons.add),
        );
      case 2:
        return FloatingActionButton(
          onPressed: () => context.go(Rotas.caminhoListaNova),
          child: const Icon(Icons.playlist_add),
        );
      default:
        return null;
    }
  }
}
