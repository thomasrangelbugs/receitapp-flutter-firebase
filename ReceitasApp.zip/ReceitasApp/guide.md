\# PROJETO: App de Receitas — Flutter + Dart + Firebase

\## Contexto acadêmico

Este projeto é um trabalho acadêmico individual que deve demonstrar:

\- Autenticação de usuário (login/cadastro)

\- Pelo menos 2 CRUDs com validação e banco de dados

\- Listagem/relatório dos dados

\- Menu de navegação centralizado

\- Recurso extra relacionado ao tema

\- UI/UX cuidadosa com componentes adequados



\## Tema escolhido

Aplicativo de receitas culinárias onde o usuário pode:

1\. Cadastrar receitas (com ingredientes, etapas e detalhes)

2\. Criar listas de receitas (com título e receitas vinculadas)

3\. Usar um timer com alarme sonoro enquanto cozinha (recurso extra)



\## Tecnologias obrigatórias

\- Flutter + Dart (mobile)

\- Firebase Auth (autenticação)

\- Cloud Firestore (banco de dados)

\- Pacotes sugeridos: audioplayers ou just\_audio (timer sonoro)



\---



\## ETAPA 1 — Estrutura e configuração inicial

Crie a estrutura de pastas e arquivos base do projeto Flutter.

Inclua:

\- pubspec.yaml com todas as dependências necessárias

\- Configuração do Firebase (google-services.json explicado)

\- Estrutura de pastas: lib/screens, lib/models, lib/services, lib/widgets

\- main.dart com MaterialApp e roteamento básico

\- Tema visual (cores, fontes, estilo geral do app)



NÃO implemente lógica ainda. Só estrutura e configuração.

Ao final, liste o que foi criado e aguarde confirmação para continuar.



\---



\## ETAPA 2 — Autenticação (Firebase Auth)

Implemente login e cadastro de usuário.

Inclua:

\- Tela de Login (email + senha) com validação de campos

\- Tela de Cadastro (nome, email, senha) com validação

\- Serviço AuthService com métodos: signIn, signUp, signOut

\- Redirecionamento automático: usuário logado → Home; não logado → Login

\- Exibição de erros amigáveis (ex: "Email já cadastrado")

\- Botão de logout acessível no app



Aguarde confirmação antes de continuar para a Etapa 3.



\---



\## ETAPA 3 — CRUD de Receitas

Implemente o gerenciamento completo de receitas.



Modelo (ReceitaModel):

\- id, userId, titulo, descricao, tempoPreparo (minutos), porcoes

\- ingredientes: List de {nome, quantidade, unidade}

\- etapas: List de {ordem, descricao, tempoPasso (minutos, opcional)}

\- dataCriacao



Telas necessárias:

\- Lista de receitas do usuário (ReceitasScreen)

\- Formulário de criação/edição (ReceitaFormScreen) com validação

\- Tela de detalhes da receita (ReceitaDetalheScreen)

\- Confirmação antes de excluir



Serviço (ReceitaService):

\- create, read (stream), update, delete no Firestore

\- Filtro por userId (cada usuário vê só as próprias receitas)



Aguarde confirmação antes de continuar para a Etapa 4.



\---



\## ETAPA 4 — CRUD de Listas de Receitas

Implemente o gerenciamento de listas.



Modelo (ListaModel):

\- id, userId, titulo, receitaIds: List<String>, dataCriacao



Telas necessárias:

\- Lista de listas do usuário (ListasScreen)

\- Formulário de criação/edição (ListaFormScreen)

&#x20; - Campo de título com validação

&#x20; - Seletor de receitas (checkbox ou chips com as receitas do usuário)

\- Tela de detalhes da lista com receitas vinculadas expandíveis

\- Opção de navegar para o detalhe de cada receita da lista



Serviço (ListaService):

\- create, read (stream), update, delete no Firestore



Aguarde confirmação antes de continuar para a Etapa 5.



\---



\## ETAPA 5 — Navegação e Menu

Implemente a navegação central do aplicativo.

Inclua:

\- BottomNavigationBar ou NavigationDrawer com os itens:

&#x20; - Início (resumo/boas-vindas)

&#x20; - Minhas Receitas

&#x20; - Minhas Listas

&#x20; - Timer (recurso extra)

\- Tela Home com: nome do usuário, contagem de receitas, contagem de listas

\- Roteamento nomeado (named routes) para todas as telas

\- AppBar consistente em todas as telas com botão de voltar onde aplicável



Aguarde confirmação antes de continuar para a Etapa 6.



\---



\## ETAPA 6 — Recurso Extra: Timer com Alarme Sonoro

Implemente o timer de cozinha (recurso extra — não relacionado aos CRUDs).

Inclua:

\- Tela TimerScreen acessível pelo menu

\- Input para definir minutos e segundos manualmente

\- Botões: Iniciar, Pausar, Reiniciar

\- Contagem regressiva visível em tempo real (grande e legível)

\- Barra de progresso visual

\- Ao chegar em 00:00: tocar um som de alarme (usando audioplayers)

&#x20; e exibir um alerta/snackbar "Tempo esgotado!"

\- Opcionalmente: ao abrir detalhe de uma etapa da receita,

&#x20; botão "Iniciar timer" com o tempoPasso preenchido automaticamente



Aguarde confirmação antes de continuar para a Etapa 7.



\---



\## ETAPA 7 — Relatório e Listagens

Garanta que todas as listagens estejam completas e bem apresentadas.

Inclua:

\- Lista de receitas: busca por título, ordenação por data

\- Lista de listas: exibição do número de receitas em cada lista

\- Tela de detalhes da receita com todos os campos organizados:

&#x20; ingredientes em tabela ou cards, etapas numeradas sequencialmente

\- Estado de lista vazia (empty state) com mensagem e botão de criar

\- Pull-to-refresh nas listas



Aguarde confirmação antes de continuar para a Etapa 8.



\---



\## ETAPA 8 — Polimento, validações e entrega

Finalize o projeto com qualidade de apresentação.

Inclua:

\- Revisão de todas as validações de formulários

\- Loading indicators (CircularProgressIndicator) em operações assíncronas

\- Tratamento de erros de rede com mensagens amigáveis

\- Consistência visual em todo o app (cores, espaçamentos, fontes)

\- Comentários no código explicando cada classe e método principal

\- README.md com: descrição do app, prints das telas, instruções de instalação,

&#x20; lista de funcionalidades implementadas e tecnologias utilizadas



\---



\## Regras gerais para todas as etapas:

\- Implemente UMA etapa por vez e aguarde minha confirmação

\- Explique brevemente o que cada arquivo faz ao criá-lo

\- Use nomenclatura em português para variáveis e métodos

\- O código deve ser limpo, comentado e seguir boas práticas Flutter

\- Separe lógica de negócio (services) da UI (screens/widgets)

\- Cada etapa deve compilar e rodar sem erros antes de avançar



Comece pela ETAPA 1 agora.

&#x20;   

